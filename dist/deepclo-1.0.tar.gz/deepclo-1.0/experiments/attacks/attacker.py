import numpy as np
from deepclo.pipe.dataset import ImageDataProvider
import matplotlib.pyplot as plt


class Attacker:
    def __init__(self, img: np.ndarray):
        self._img = img

    def one_pixel_attack(self, xs):
        """

        Args:
            xs: # pixel position and color = x,y,r,g,b

        Returns:

        """
        # If this function is passed just one perturbation vector,
        # pack it in a list to keep the computation the same
        if xs.ndim < 2:
            xs = np.array([xs])

        # Copy the image n == len(xs) times so that we can
        # create n new perturbed images
        tile = [len(xs)] + [1] * (xs.ndim + 1)
        imgs = np.tile(self._img, tile)

        # Make sure to floor the members of xs as int types
        xs = xs.astype(int)

        for x, img in zip(xs, imgs):
            # Split x into an array of 5-tuples (perturbation pixels)
            # i.e., [[x,y,r,g,b], ...]
            pixels = np.split(x, len(x) // 5)
            for pixel in pixels:
                # At each pixel's x,y position, assign its rgb value
                x_pos, y_pos, *rgb = pixel
                img[x_pos, y_pos] = rgb

        return imgs

    def patch_attack(self):
        pass


def plot_image(image, label_true=None, class_names=None, label_pred=None):
    if image.ndim == 4 and image.shape[0] == 1:
        image = image[0]

    plt.grid()
    plt.imshow(image.astype(np.uint8))

    # Show true and predicted classes
    if label_true is not None and class_names is not None:
        labels_true_name = class_names[label_true]
        if label_pred is None:
            xlabel = "True: " + labels_true_name
        else:
            # Name of the predicted class
            labels_pred_name = class_names[label_pred]

            xlabel = "True: " + labels_true_name + "\nPredicted: " + labels_pred_name

        # Show the class on the x-axis
        plt.xlabel(xlabel)

    plt.xticks([])  # Remove ticks from the plot
    plt.yticks([])
    plt.show()  # Show the plot


ds = ImageDataProvider(dataset_name='cifar10')
# assert ds.x_train.shape == (50000, 32, 32, 3)
print(ds.input_shape)
assert ds.input_shape == (32, 32, 3)
image_id = 99
plot_image(ds.x_test[image_id])
attacker = Attacker(ds.x_test[image_id])

attack_vectors = [
    np.array([4, 4, 255, 255, 0]),
    np.array([30, 4, 255, 255, 0]),
    np.array([4, 30, 255, 255, 0]),
    np.array([30, 30, 255, 255, 0]),
    np.array([16, 16, 255, 255, 0])]
# pixel = y, x, r,g,b

for pixel in attack_vectors:
    image_perturbed = attacker.one_pixel_attack(pixel)
    plot_image(image_perturbed[0])
